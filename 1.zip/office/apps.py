from django.apps import AppConfig


class OfficeConfig(AppConfig):
    name = 'office'
