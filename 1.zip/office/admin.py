from django.contrib import admin

from office.models import Office

admin.site.register(Office)
