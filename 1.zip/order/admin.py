from django.contrib import admin

from order.models import Order

admin.site.register(Order)
