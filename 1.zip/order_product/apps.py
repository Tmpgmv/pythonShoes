from django.apps import AppConfig


class OrderProductConfig(AppConfig):
    name = 'order_product'
    verbose_name = "Товары в заказах"