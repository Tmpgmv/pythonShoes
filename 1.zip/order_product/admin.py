from django.contrib import admin

from order_product.models import OrderProduct

admin.site.register(OrderProduct)
